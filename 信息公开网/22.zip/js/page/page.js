$(document).ready(function() {
    $(".child").before('<td class="li"></td>');
    $("#menul").css("top", "200px");
    $('.search').find('img')[0].setAttribute('src', '/page/main1853/images/serach.jpg')
});