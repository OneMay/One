$(document).ready(function() {
    $(".child").before('<td class="li"></td>');
    $("#menul").css("top", "200px");
});